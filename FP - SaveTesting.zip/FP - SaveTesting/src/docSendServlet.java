

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/docSendServlet")
public class docSendServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public docSendServlet() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String userID = request.getParameter("userID");
		String docID = request.getParameter("docID");
		
		//assuming this user and doc are valid entries in the db 
		//not doing the check here this is just for testing
		
		request.setAttribute("userID", userID);
		request.setAttribute("docID", docID);
		//sending the data to the page so it knows which doc page to load and for which user
		
		String next = "/docPage.jsp";
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(next);
		dispatch.forward(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
