DROP DATABASE IF EXISTS SaveTest;
CREATE DATABASE SaveTest;

USE SaveTest;
CREATE TABLE Master (
	-- MASTER TABLE --
    -- will hold every document and every user that has access to that document in a new row --
		-- note: order may not be sequential --
	docID INT (11),
    userID INT(11),
    content TEXT(900000000) 
);

INSERT INTO Master (docID, userID, content) 
	VALUE (1, 1, null);